var searchData=
[
  ['cache_5fdir',['CACHE_DIR',['../classgg.html#a56b2cb83067574966250e4ca7a31e714',1,'gg']]]
];
