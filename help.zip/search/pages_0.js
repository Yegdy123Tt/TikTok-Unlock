var searchData=
[
  ['config_20help',['Config help',['../config.html',1,'']]],
  ['contextual_20help',['Contextual help',['../context.html',1,'']]]
];
