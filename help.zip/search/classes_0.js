var searchData=
[
  ['gg',['gg',['../classgg.html',1,'']]]
];
