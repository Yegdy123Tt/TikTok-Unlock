var searchData=
[
  ['version',['VERSION',['../classgg.html#a48e98402033e0f924454fedb735cddc5',1,'gg']]],
  ['version_5fint',['VERSION_INT',['../classgg.html#af4af5fbbf2363c346c0a08e2a91edada',1,'gg']]]
];
