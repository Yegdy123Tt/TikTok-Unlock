var searchData=
[
  ['region_5fanonymous',['REGION_ANONYMOUS',['../classgg.html#a8800a1a35506371584bac146a4d1423a',1,'gg']]],
  ['region_5fashmem',['REGION_ASHMEM',['../classgg.html#a752a903134a2596a06a3234870b019b2',1,'gg']]],
  ['region_5fbad',['REGION_BAD',['../classgg.html#a336f4a83412f422741f9ddfe99d945f0',1,'gg']]],
  ['region_5fc_5falloc',['REGION_C_ALLOC',['../classgg.html#aca2a5deffecb010854de13757b39f6b4',1,'gg']]],
  ['region_5fc_5fbss',['REGION_C_BSS',['../classgg.html#a9784dbd9f055af3dd7c2b2abef080636',1,'gg']]],
  ['region_5fc_5fdata',['REGION_C_DATA',['../classgg.html#a8c3dfa9ea4f70873ca6e7074b925db35',1,'gg']]],
  ['region_5fc_5fheap',['REGION_C_HEAP',['../classgg.html#ad5ab1a083df916bbd606546ea1c02702',1,'gg']]],
  ['region_5fcode_5fapp',['REGION_CODE_APP',['../classgg.html#ae9b162358f2c542801ce5e2bd0f660d1',1,'gg']]],
  ['region_5fcode_5fsys',['REGION_CODE_SYS',['../classgg.html#a3bef292ed43881da93b5c0ec96137699',1,'gg']]],
  ['region_5fjava',['REGION_JAVA',['../classgg.html#a6cb48517aa068ab19064742fda5f8ea8',1,'gg']]],
  ['region_5fjava_5fheap',['REGION_JAVA_HEAP',['../classgg.html#a39f66e68d964ef9ced7cc0ddf83a9cb3',1,'gg']]],
  ['region_5fother',['REGION_OTHER',['../classgg.html#a6a39cc2e4befe27202ce1d5bfa2aa558',1,'gg']]],
  ['region_5fppsspp',['REGION_PPSSPP',['../classgg.html#a16d1eb0be707658aed133c7478ceee28',1,'gg']]],
  ['region_5fstack',['REGION_STACK',['../classgg.html#ad8b6c9db3aa55fc5bd9c00832fae2cda',1,'gg']]],
  ['region_5fvideo',['REGION_VIDEO',['../classgg.html#a6d0278ea523b2612ded1ab94c1827a91',1,'gg']]]
];
