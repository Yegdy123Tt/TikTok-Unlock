var searchData=
[
  ['files_5fdir',['FILES_DIR',['../classgg.html#aa18a4dcf8e06c07c5a4878e914d69e03',1,'gg']]],
  ['freeze_5fin_5frange',['FREEZE_IN_RANGE',['../classgg.html#a62dad86d8996b200fee5b929020cc974',1,'gg']]],
  ['freeze_5fmay_5fdecrease',['FREEZE_MAY_DECREASE',['../classgg.html#acfb1959fb4c13a703d8940a8c69dfefa',1,'gg']]],
  ['freeze_5fmay_5fincrease',['FREEZE_MAY_INCREASE',['../classgg.html#a5f83517e832d9802d3a220fa66e40892',1,'gg']]],
  ['freeze_5fnormal',['FREEZE_NORMAL',['../classgg.html#a2e8ea09fae1c59d8fc33f5b0cd9c13b6',1,'gg']]]
];
