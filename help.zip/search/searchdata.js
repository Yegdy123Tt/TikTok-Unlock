var indexSectionsWithContent =
{
  0: "abcdefghilmnprstuv",
  1: "g",
  2: "abcdeghilmnprstu",
  3: "abcdeflprstv",
  4: "cfhls"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Pages"
};

