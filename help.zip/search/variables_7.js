var searchData=
[
  ['package',['PACKAGE',['../classgg.html#a3fc64bcd833351c4f7b55c634742fa15',1,'gg']]],
  ['pointer_5fexecutable',['POINTER_EXECUTABLE',['../classgg.html#ac59e6cbf0f8d004ec3867d6fd59882fb',1,'gg']]],
  ['pointer_5fexecutable_5fwritable',['POINTER_EXECUTABLE_WRITABLE',['../classgg.html#a73ab14d1fc43bd0fe3e301e51cf8bdbc',1,'gg']]],
  ['pointer_5fno',['POINTER_NO',['../classgg.html#aeb86beab2efbdb1d75d520d5bdf7746a',1,'gg']]],
  ['pointer_5fread_5fonly',['POINTER_READ_ONLY',['../classgg.html#a2f9839a3f49f428a231e8f3ece94da2b',1,'gg']]],
  ['pointer_5fwritable',['POINTER_WRITABLE',['../classgg.html#a631fb1ed5b1f7d6025992df66d02548f',1,'gg']]],
  ['prot_5fexec',['PROT_EXEC',['../classgg.html#a6e6a12e26a4412d7797832a72a93df06',1,'gg']]],
  ['prot_5fnone',['PROT_NONE',['../classgg.html#a368c1986d14c95ffd5431089868533ce',1,'gg']]],
  ['prot_5fread',['PROT_READ',['../classgg.html#a29f6b407593a8f8188af60d6012e160d',1,'gg']]],
  ['prot_5fwrite',['PROT_WRITE',['../classgg.html#abb8499ac6dfdc43ad2b7fe9056cc5e5d',1,'gg']]]
];
