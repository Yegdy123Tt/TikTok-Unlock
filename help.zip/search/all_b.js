var searchData=
[
  ['numberfromlocale',['numberFromLocale',['../classgg.html#a6b00bebbe49d7b71e81eb394b7c1bd60',1,'gg']]],
  ['numbertolocale',['numberToLocale',['../classgg.html#ae8d36bdd3fa61c880d4ac01aa1fb7840',1,'gg']]]
];
