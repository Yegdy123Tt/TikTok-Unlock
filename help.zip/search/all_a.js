var searchData=
[
  ['makerequest',['makeRequest',['../classgg.html#ad020d50d3af0a36733e0cbc231055c55',1,'gg']]],
  ['multichoice',['multiChoice',['../classgg.html#a1325b0f7c85d6ad6dd8c6f87ada2e126',1,'gg']]]
];
