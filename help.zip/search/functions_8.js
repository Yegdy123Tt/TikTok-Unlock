var searchData=
[
  ['loadlist',['loadList',['../classgg.html#a5ddfc95e74d6db1b10edfac77da9c7bd',1,'gg']]],
  ['loadresults',['loadResults',['../classgg.html#ade5f40667e80938ba1678d0623fe7b82',1,'gg']]]
];
